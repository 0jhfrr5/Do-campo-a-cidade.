let truckX = 50;
let truckY = 300;
let score = 0;
let gameState = "playing";

function setup() {
  let canvas = createCanvas(800, 400);
  canvas.parent("game-container");
  textFont('Georgia');
}

function draw() {
  background(135, 206, 235);
  drawGround();
  drawField();
  drawCity();
  drawFlags();
  drawTruck();
  drawUI();

  if (gameState === "playing") {
    handleInput();
    checkDelivery();
    checkBounds();
  } else if (gameState === "gameover") {
    drawGameOver();
  }
}

// 🌱 Campo
function drawField() {
  fill(34, 139, 34);
  rect(0, 250, width / 2, 150);
  fill(139, 69, 19);
  rect(80, 200, 60, 50);
  fill(255);
  triangle(80, 200, 110, 170, 140, 200);
}

// 🏙️ Cidade
function drawCity() {
  fill(169, 169, 169);
  for (let i = 0; i < 4; i++) {
    let x = 500 + i * 60;
    rect(x, 180 - i * 20, 40, 220);
    fill(255);
    rect(x + 10, 200 - i * 20, 10, 10);
    fill(169, 169, 169);
  }
  fill(255, 0, 0);
  ellipse(700, 55, 10, 10);
}

// 🚚 Caminhão
function drawTruck() {
  fill(255, 0, 0);
  rect(truckX, truckY, 60, 30);
  fill(0);
  ellipse(truckX + 10, truckY + 30, 15, 15);
  ellipse(truckX + 50, truckY + 30, 15, 15);
  fill(255);
  textSize(12);
  text("Produtos", truckX + 5, truckY + 20);
}

// 🎈 Bandeirinhas
function drawFlags() {
  let numFlags = 20;
  let flagY = height / 4;
  for (let i = 0; i < numFlags; i++) {
    let x = i * (width / numFlags);
    let colorIndex = i % 3;
    if (colorIndex == 0) fill('red');
    else if (colorIndex == 1) fill('green');
    else fill('yellow');
    triangle(x, flagY, x + 20, flagY, x + 10, flagY + 20);
  }
}

// 🌳 Solo
function drawGround() {
  fill(139, 69, 19);
  rect(0, 330, width, 70);
}

// 🎮 Controles
function handleInput() {
  if (keyIsDown(LEFT_ARROW)) {
    truckX -= 3;
  }
  if (keyIsDown(RIGHT_ARROW)) {
    truckX += 3;
  }
}

// ✅ Entrega
function checkDelivery() {
  if (truckX > width - 100) {
    score += 1;
    truckX = 50;
  }
}

// ❌ Limites
function checkBounds() {
  if (truckY > 330 || truckX < -60 || truckX > width + 60) {
    gameState = "gameover";
  }
}

// 🧾 Pontuação e título
function drawUI() {
  fill(255);
  textSize(20);
  textAlign(LEFT);
  text("Entregas: " + score, 20, 30);
  textAlign(CENTER);
  text("Festejando a Conexão Campo-Cidade!", width / 2, 50);
}

// 💀 Fim de jogo
function drawGameOver() {
  fill(0, 0, 0, 180);
  rect(0, 0, width, height);
  fill(255);
  textSize(30);
  textAlign(CENTER);
  text("🚧 Fim de Jogo!", width / 2, height / 2 - 20);
  textSize(20);
  text("Você fez " + score + " entregas!", width / 2, height / 2 + 20);
  text("Atualize a página para jogar novamente", width / 2, height / 2 + 50);
}